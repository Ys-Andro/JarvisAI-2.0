#pragma once

#define MANUAL_JUMP_TITLE_ID       0x0004000000033500ULL
#define MANUAL_JUMP_CONFIG_PATH    "/luma/plugins/0004000000033500/ManualJump.cfg"

/* SingleScreen 3.2.2 USA Emulator patch signatures and runtime addresses. */
#define SS_HOOK_CALLSITE           0x00452390u
#define SS_WRAPPER_ADDR            0x005C7604u
#define SS_UPDATE_ROUTINE          0x0060C388u
#define SS_INPUT_CONTEXT           0x00630354u

#define SS_EXPECT_WRAPPER_PUSH     0xE92D5FFFu
#define SS_EXPECT_WRAPPER_BL       0xEB01135Eu
#define SS_EXPECT_WRAPPER_POP      0xE8BD5FFFu

/* OoT3D USA Rev 1 bindings audited from Ocarina ReTuned 2.5.1. */
#define OOT_MENU_STATE_ADDR        0x0050AF68u
#define OOT_SAVE_CONTEXT_ADDR      0x00587958u
#define OOT_PLAYER_JUMP_ADDR       0x0034B3DCu
#define OOT_PLAYER_ACTION_A        0x004BA378u
#define OOT_PLAYER_ACTION_B        0x004A279Cu
#define OOT_PLAYER_ACTION_C        0x004A34D0u

#define OOT_INPUT_HID_ADDR         0x10002000u
#define OOT_INPUT_PAD_OFFSET       0x28u
#define OOT_INPUT_PAD_INDEX_OFFSET 0x10u

#define OOT_INPUT_X                (1u << 10)
#define OOT_INPUT_L                (1u << 9)
#define OOT_INPUT_R                (1u << 8)
#define OOT_INPUT_ZR               (1u << 15)

#define OOT_INPUT_HELD_OFFSET      0x14u
#define OOT_INPUT_PRESSED_OFFSET   0x18u
#define OOT_INPUT_RELEASED_OFFSET  0x1Cu

#define OOT_PLAYER_BG_FLAGS        0x90u
#define OOT_PLAYER_HELD_ACTOR      0x1224u
#define OOT_PLAYER_GUARD_BYTE_A    0x12BCu
#define OOT_PLAYER_STATE_FUNC      0x1708u
#define OOT_PLAYER_GUARD_BYTE_B    0x1A7u

#define OOT_SAVE_HEALTH_OFFSET     0x44u
#define OOT_SAVE_GAMEMODE_OFFSET   0x14E4u
#define OOT_GAMEOVER_STATE_OFFSET  0x318Cu

#define MANUAL_JUMP_MODE_OFF       0u
#define MANUAL_JUMP_MODE_ZR        1u
#define MANUAL_JUMP_MODE_X         2u

#define ARM_LDR_PC_LITERAL_NEG4    0xE51FF004u
