# Changelog

## v0.1 - 2026-11-20

- Primer diseño de plugin 3GX independiente para SingleScreen 3.2.2 USA.
- Hook en tiempo de ejecución sobre el wrapper verificado de SingleScreen.
- Encadenamiento de la rutina original de SingleScreen antes de procesar entrada de salto.
- Modos externos `off`, `zr` y `x`.
- Reasignación de la función del botón X a ZR en modo X.
- Guardas de firma, suspensión de hilos y gestión de caché ARM.
- Pruebas locales de política, firmas IPS/ExHeader y ensamblado ARM.
- Sin binario `.3gx` ni prueba de ejecución en Azahar todavía.
