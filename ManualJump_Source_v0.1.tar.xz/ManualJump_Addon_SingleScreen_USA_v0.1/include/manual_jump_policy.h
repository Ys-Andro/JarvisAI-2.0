#pragma once
#include <stdint.h>

#define MJ_X_MASK  (1u << 10)
#define MJ_ZR_MASK (1u << 15)

static inline unsigned MJ_ValidMode(unsigned mode) {
    return mode <= 2u ? mode : 0u;
}

static inline int MJ_ShouldJump(unsigned mode, int gameplay, int chord,
                                int x_pressed, int zr_pressed) {
    if (!gameplay || chord) return 0;
    if (mode == 1u) return zr_pressed;
    if (mode == 2u) return x_pressed;
    return 0;
}

static inline uint32_t MJ_RemapXToZR(uint32_t original, uint32_t zr_mask) {
    return (original & ~MJ_X_MASK) | ((zr_mask & MJ_ZR_MASK) ? MJ_X_MASK : 0u);
}
