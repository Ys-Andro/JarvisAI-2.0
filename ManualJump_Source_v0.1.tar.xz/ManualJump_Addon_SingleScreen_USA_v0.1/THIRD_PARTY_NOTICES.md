# Third-party notices

## Ocarina ReTuned / OOT3DHud

The USA Rev 1 movement, input and native jump bindings were researched against the public source of Ocarina ReTuned / OOT3DHud 2.5.1:
https://github.com/OTPR26/OOT3DHud

This project is an independent implementation of the described behavior, not a copy of its complete plugin or game patch. The upstream project identifies its source under GPL-2.0-or-later. See its repository for the original notices and third-party materials.

## CTRComposer

The 3GX startup, TLS initialization and SD access patterns were informed by CTRComposer:
https://github.com/samaBR85/CTRComposer

No CTRComposer menu, renderer, or cheat engine source is bundled here. CTRComposer's source carries its own notices; consult the upstream repository before reusing any of its files.

## SingleScreen

No SingleScreen IPS patch or ExHeader is distributed in this source package. The provided SingleScreen files were used only as local inputs for signature verification. All rights in SingleScreen remain with its author(s).
