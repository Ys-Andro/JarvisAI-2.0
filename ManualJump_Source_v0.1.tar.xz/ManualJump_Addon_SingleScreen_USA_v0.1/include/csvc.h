#pragma once
#include <3ds/types.h>

/* libctru does not expose this Luma/Citra process operation in its normal API. */
typedef enum ManualJumpProcessOp {
    MANUAL_JUMP_PROCESSOP_SCHEDULE_THREADS_WITHOUT_TLS_MAGIC = 6
} ManualJumpProcessOp;

Result svcControlProcess(Handle process, u32 operation, u32 argument2, u32 argument3);
void svcFlushEntireDataCache(void);
void svcInvalidateEntireInstructionCache(void);
